
yolo v5 pothole detection median blur - v1 nayantara maam pothole detection median blur
==============================

This dataset was exported via roboflow.ai on November 19, 2021 at 10:15 AM GMT

It includes 840 images.
Potholes are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


